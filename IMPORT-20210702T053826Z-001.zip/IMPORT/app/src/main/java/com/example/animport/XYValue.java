package com.example.animport;

public class XYValue {

    private double x;


    public XYValue(double x) {
        this.x = x;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }


}

